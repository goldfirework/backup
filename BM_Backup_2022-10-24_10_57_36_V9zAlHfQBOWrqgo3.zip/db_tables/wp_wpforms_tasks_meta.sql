/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_wpforms_tasks_meta`; */
/* PRE_TABLE_NAME: `1666609056_wp_wpforms_tasks_meta`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1666609056_wp_wpforms_tasks_meta` ( `id` bigint NOT NULL AUTO_INCREMENT, `action` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL, `data` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL, `date` datetime NOT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1666609056_wp_wpforms_tasks_meta` (`id`, `action`, `data`, `date`) VALUES (1,'wpforms_process_forms_locator_scan','W10=','2022-10-21 11:40:44'),(3,'wpforms_admin_addons_cache_update','W10=','2022-10-21 11:41:00'),(4,'wpforms_admin_builder_templates_cache_update','W10=','2022-10-21 11:41:00'),(7,'wpforms_process_forms_locator_scan','W10=','2022-10-24 09:06:19');
