/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_wpmm_subscribers`; */
/* PRE_TABLE_NAME: `1666609056_wp_wpmm_subscribers`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1666609056_wp_wpmm_subscribers` ( `id_subscriber` bigint NOT NULL AUTO_INCREMENT, `email` varchar(50) NOT NULL, `insert_date` datetime NOT NULL, PRIMARY KEY (`id_subscriber`)) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
INSERT INTO `1666609056_wp_wpmm_subscribers` (`id_subscriber`, `email`, `insert_date`) VALUES (1,'thallaugj@gmail.com','2022-10-24 08:57:53');
